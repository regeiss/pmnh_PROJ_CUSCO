import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:gtk_flutter/src/core/router/routes.dart';

class LoginSection extends StatelessWidget {
  const LoginSection({ super.key,});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('Já tem uma conta? '),
            TextButton(
              child: const Text('Entrar'),
              onPressed: () => context.go(Routes.loginOK),
              ),
          ],
      )
    );
  }
}