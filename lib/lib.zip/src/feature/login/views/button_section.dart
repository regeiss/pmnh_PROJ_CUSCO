import 'package:flutter/material.dart';
import 'package:flutter_social_button/flutter_social_button.dart';
import 'package:go_router/go_router.dart';
import 'package:gtk_flutter/src/core/router/routes.dart';

class ButtonSection extends StatelessWidget {
  const ButtonSection({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
         children: [
            IconButton(
            icon: FaIcon(FontAwesomeIcons.google,
            size: 50,
            color: Colors.red),
            onPressed: () => context.go(Routes.loginGoogle),
            ),
            IconButton(
              icon: FaIcon(FontAwesomeIcons.facebook,
              size: 50,
              color: Colors.blue,),
              onPressed: () => context.go(Routes.loginGoogle),
            ),
            IconButton(
              icon: FaIcon(FontAwesomeIcons.whatsapp,
              size: 50,
              color: Colors.green,),
              onPressed: () => context.go(Routes.loginGoogle),
            ),
            IconButton(
              icon: FaIcon(FontAwesomeIcons.apple,
              size: 50,
              color: Colors.black,),
              onPressed: () => context.go(Routes.loginGoogle),
            ),
            IconButton(
              icon: FaIcon(FontAwesomeIcons.mailchimp,
              size: 50,
              color: Colors.brown,),
              onPressed: () => context.go(Routes.loginGoogle),
            ),
          ],
      )
    );
  }
}